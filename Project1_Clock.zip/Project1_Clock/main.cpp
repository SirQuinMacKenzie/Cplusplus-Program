// Clock Display and Edit Program
//  Author: Quinlin MacKenzie-Hager
// Date: 2023/09/24
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

// Function to format numbers as two digits
string formatTwoDigits(int number) {
    stringstream ss;
    ss << setw(2) << setfill('0') << number;
    return ss.str();
}

// Function to output time using both 12-hour and 24-hour formats inside boxes
void displayClocks(int hours, int minutes, int seconds) {
    cout << "*************************" << endl;
    cout << "*     12-Hour Clock     *" << endl;
    cout << "*       " << formatTwoDigits(hours) << ":" << formatTwoDigits(minutes) << ":" << formatTwoDigits(seconds) << "        *" << endl;
    cout << "*************************" << endl;

    string am_pm = (hours < 12) ? "AM" : "PM";
    if (hours == 0) hours = 12;
    else if (hours > 12) hours -= 12;

    cout << "*************************" << endl;
    cout << "*     24-Hour Clock     *" << endl;
    cout << "*       " << formatTwoDigits(hours) << ":" << formatTwoDigits(minutes) << ":" << formatTwoDigits(seconds) << " " << am_pm << "     *" << endl;
    cout << "*************************" << endl;
}

// Function to print the menu inside a box
void printMenu() {
    cout << "*************************" << endl;
    cout << "*        Menu           *" << endl;
    cout << "* 1. Display Clocks     *" << endl;
    cout << "* 2. Add one second     *" << endl;
    cout << "* 3. Add one minute     *" << endl;
    cout << "* 4. Add one hour       *" << endl;
    cout << "* 5. Exit               *" << endl;
    cout << "*************************" << endl;
}

// Function to add a second to the clock's time
void addSecond(int& hours, int& minutes, int& seconds) {
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            hours++;
            if (hours >= 24) {
                hours = 0;
            }
        }
    }
}

// Function to add a minute to the clock's time
void addMinute(int& hours, int& minutes, int& seconds) {
    minutes++;
    if (minutes >= 60) {
        minutes = 0;
        hours++;
        if (hours >= 24) {
            hours = 0;
        }
    }
}

// Function to add an hour to the clock's time
void addHour(int& hours, int& minutes, int& seconds) {
    hours++;
    if (hours >= 24) {
        hours = 0;
    }
}

int main() {
    int hours, minutes, seconds;

    cout << "Please enter the initial time:" << endl;
    cout << "Hours (0-23): ";
    cin >> hours;
    cout << "Minutes (0-59): ";
    cin >> minutes;
    cout << "Seconds (0-59): ";
    cin >> seconds;

    if (hours < 0 || hours >= 24 || minutes < 0 || minutes >= 60 || seconds < 0 || seconds >= 60) {
        cout << "Invalid time input. Exiting." << endl;
        return 1;
    }

    int choice = 0;
    while (choice != 5) {
        printMenu();
        cin >> choice;

        if (choice == 1) {
            displayClocks(hours, minutes, seconds);
        }
        else if (choice == 2) {
            addSecond(hours, minutes, seconds);
        }
        else if (choice == 3) {
            addMinute(hours, minutes, seconds);
        }
        else if (choice == 4) {
            addHour(hours, minutes, seconds);
        }
        else if (choice == 5) {
            cout << "Program Exit" << endl;
        }
        else {
            cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}
